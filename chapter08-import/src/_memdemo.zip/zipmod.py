WHO = "zipmod"
def greet():
    return "hello from %s in _memdemo.zip" % WHO
print("[zipmod] 模块体执行，__file__=%s" % __file__)
